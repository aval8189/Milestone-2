﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text.RegularExpressions;

//using UnityEngine;
using UnityEditor;
using System.IO;

// This script is to read the information that a text file has.
// With this information we should at least spread it to held.
public class InfoHolder : MonoBehaviour {

	/*writes and creates a text file
	[MenuItem("Tools/Write file")]
	static void WriteString(){
		string path = "Assets/Resources/test.txt";

	}*/

	//public static string course_name;
	public static string[] week_work;

	static string content = "";

	public static int num_weeks;

	[MenuItem("Tools/Read file")]
	static void ReadString(){
		string path = "Assets/test.txt";

		//reads the text form the textfile
		//StreamReader reader = new StreamReader(path);
		//every line is then put into a public dynamic array 
		//which will also be a public counter that will be out number of "level" that they will be.
		using (StreamReader reader = new StreamReader (path, true)) {
			content = reader.ReadToEnd ();
		}

		week_work = content.Split ('\n');

		num_weeks = week_work.Length;
		/*numberofweeks = reader.ReadLine().ToString().Split('\n');
		course_name = reader.ReadLine ();

		foreach (string line in numberofweeks) {
			numberofweeks[num_weeks++] = line.Split ('\n');
			Debug.Log (numberofweeks[--num_weeks]);
		}*/


		//Debug.Log (reader.ReadToEnd ());
		//course_name = reader.ReadLine ();
		//Debug.Log (course_name);

		// Tesing if the storing works by knowing if there are things in the array.
		Debug.Log(week_work[1]);
		Debug.Log(num_weeks);

		//reader.Close();
	}



	// Use this for initialization
	void Start () {
		ReadString ();


		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
